/**
 * 定义从第三方 API 返回的插画信息。这里只抽取需要的字段，便于消息生成。
 */
export interface IllustInfo {
  /** Pixiv 作品 ID */
  pid: number;
  /** 插画标题 */
  title: string;
  /** 作者名字 */
  author: string;
  /** 标签列表 */
  tags: string[];
  /** 图片原图 URL */
  url: string;
  /** 是否是 R18 */
  r18: boolean;
}

/**
 * 第三方接口地址。我们使用 lolicon.app 提供的公开接口，它会从 Pixiv 抽取插画信息并提供 CDN 直链。
 * 文档: https://api.lolicon.app/#/setu
 */
const API_BASE = 'https://api.lolicon.app/setu/v2';

/**
 * 向第三方接口发起请求，获取插画信息。
 * @param params 请求参数
 */
async function fetchIllusts(params: Record<string, any>): Promise<IllustInfo[]> {
  try {
    // 构造查询字符串
    const query = new URLSearchParams(params as Record<string, string>).toString();
    const url = `${API_BASE}?${query}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = (await res.json()) as any;
    const data = json?.data || [];
    const illusts: IllustInfo[] = data.map((item: any) => {
      return {
        pid: item.pid,
        title: item.title,
        author: item.author,
        tags: item.tags || [],
        url: item.urls?.original || item.urls?.regular || '',
        r18: Boolean(item.r18),
      } as IllustInfo;
    });
    return illusts;
  } catch (err) {
    console.warn('请求插画接口失败', err);
    return [];
  }
}

/**
 * 根据关键词搜索插画。
 * @param tag 关键词（可为中文或日文标签）
 * @param num 返回数量
 * @param allowR18 是否允许返回 R18 作品
 */
export async function searchIllusts(tag: string, num: number, allowR18: boolean): Promise<IllustInfo[]> {
  const params: Record<string, any> = {
    tag,
    num,
    r18: allowR18 ? 1 : 0,
    size: 'regular',
  };
  return fetchIllusts(params);
}

/**
 * 获取随机推荐插画。如果不指定关键词则随机推荐。
 * @param num 返回数量
 * @param allowR18 是否允许返回 R18 作品
 */
export async function recommendIllusts(num: number, allowR18: boolean): Promise<IllustInfo[]> {
  const params: Record<string, any> = {
    num,
    r18: allowR18 ? 1 : 0,
    size: 'regular',
  };
  return fetchIllusts(params);
}