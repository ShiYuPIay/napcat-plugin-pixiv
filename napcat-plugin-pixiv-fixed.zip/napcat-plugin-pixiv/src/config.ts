// 若未安装 napcat-types，使用 any 代替类型。
type PluginConfigSchema = any;

/**
 * 插件配置接口。通过 NapCat WebUI 修改这些配置可以改变插件行为。
 */
export interface PluginConfig {
  /** 是否启用插件 */
  enabled: boolean;
  /** 调用插件的命令前缀，例如 #pixiv */
  commandPrefix: string;
  /** 每次返回的最大插画数量 */
  maxResults: number;
  /** 是否允许返回 R18 作品 */
  allowR18: boolean;
}

/**
 * 默认配置。当用户未在配置界面设置时，会使用这些值。
 */
export function defaultConfig(): PluginConfig {
  return {
    enabled: true,
    commandPrefix: '#pixiv',
    maxResults: 3,
    allowR18: false,
  };
}

/**
 * 构建插件配置的 Schema，用于在 NapCat WebUI 自动生成配置面板。
 * @param ctx 插件上下文
 */
export function buildConfigSchema(
  ctx: any,
): PluginConfigSchema {
  const { NapCatConfig } = ctx;
  return [
    NapCatConfig.boolean({
      key: 'enabled',
      label: '启用插件',
      default: true,
      description: '是否启用 Pixiv 搜索与推荐功能',
    }),
    NapCatConfig.text({
      key: 'commandPrefix',
      label: '指令前缀',
      default: '#pixiv',
      placeholder: '例如 #pixiv',
      description: '调用本插件的指令前缀',
    }),
    NapCatConfig.number({
      key: 'maxResults',
      label: '最大结果数量',
      default: 3,
      min: 1,
      max: 10,
      description: '每次搜索或推荐返回图片的最大数量',
    }),
    NapCatConfig.boolean({
      key: 'allowR18',
      label: '允许 R18',
      default: false,
      description: '是否允许返回 R18 插画',
    }),
  ];
}