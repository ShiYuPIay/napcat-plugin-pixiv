// 若未安装 napcat-types，使用 any 类型代替 NapCatPluginContext。
type NapCatPluginContext = any;
import { defaultConfig, type PluginConfig } from '../config';

/**
 * 插件全局状态管理。
 * 在插件初始化时保存上下文和配置，后续可以在消息处理器中访问。
 */
class PluginState {
  /** 当前插件上下文 */
  public ctx: NapCatPluginContext | null = null;
  /** 当前配置 */
  public config: PluginConfig = defaultConfig();

  /** 初始化状态，记录上下文并加载配置 */
  init(ctx: NapCatPluginContext) {
    this.ctx = ctx;
    // 合并已有配置（如果存在）
    try {
      const storedConfig = (ctx as any).pluginData?.config as
        | Partial<PluginConfig>
        | undefined;
      if (storedConfig) {
        this.config = { ...this.config, ...storedConfig };
      }
    } catch {
      // ignore
    }
  }

  /** 更新配置（用于 WebUI 单项变更） */
  updateConfig(partial: Partial<PluginConfig>) {
    this.config = { ...this.config, ...partial };
  }

  /** 替换整个配置 */
  replaceConfig(conf: PluginConfig) {
    this.config = conf;
  }

  /** 获取日志记录器，若上下文不存在则返回 console */
  get logger() {
    return this.ctx?.logger ?? console;
  }
}

export const pluginState = new PluginState();