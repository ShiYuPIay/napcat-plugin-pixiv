// 为了兼容未安装 napcat-types 的环境，使用 any 类型。
// NapCat 插件环境会在运行时注入正确的上下文对象，这里无需显式类型。
type NapCatPluginContext = any;
type OB11Message = any;
type OB11PostSendMsg = any;

// 定义消息事件类型常量，OneBot 规范中消息事件的 post_type 为 'message'。
const MESSAGE_POST_TYPE = 'message';
import { pluginState } from '../core/state';
import { searchIllusts, recommendIllusts, type IllustInfo } from '../services/pixiv-service';

/**
 * 消息段构造函数：文本消息
 */
function textSegment(text: string) {
  return { type: 'text', data: { text } };
}

/**
 * 消息段构造函数：图片消息
 * NapCat 支持通过网络链接发送图片，需填写 file 字段。
 */
function imageSegment(url: string) {
  return { type: 'image', data: { file: url } };
}

/**
 * 合并转发消息节点类型
 */
interface ForwardNode {
  /**
   * NapCat 转发消息节点。根据 OneBot 11 规范，节点包含发言者昵称、QQ 号以及消息内容。
   * 当不指定 user_id 时，NapCat 会将触发命令的用户视作发言者，从而在合并转发中显示其头像与昵称。
   * 为了避免泄露触发者的个人信息及减少被恶意举报的风险，此插件在构建转发节点时显式指定
   * user_id 为当前机器人的 QQ 号（从事件 self_id 获取）。这样合并转发消息中的每个节点都会
   * 显示机器人本身的头像和插件定义的昵称，而不是触发者的头像和昵称。
   */
  type: 'node';
  data: {
    /** 节点显示的昵称 */
    nickname: string;
    /** 显示的 QQ 号，若不指定则默认使用触发者的 user_id */
    user_id?: string;
    /** 节点包含的消息段 */
    content: Array<{ type: string; data: Record<string, unknown> }>;
  };
}

/**
 * 根据事件发送回复。自动处理群聊和私聊。
 */
async function sendReply(
  ctx: NapCatPluginContext,
  event: OB11Message,
  message: OB11PostSendMsg['message'],
): Promise<boolean> {
  try {
    const params: OB11PostSendMsg = {
      message,
      message_type: event.message_type,
      ...(event.message_type === 'group' && event.group_id
        ? { group_id: String(event.group_id) }
        : {}),
      ...(event.message_type === 'private' && event.user_id
        ? { user_id: String(event.user_id) }
        : {}),
    } as OB11PostSendMsg;
    await ctx.actions.call('send_msg', params, ctx.adapterName, ctx.pluginManager.config);
    return true;
  } catch (err) {
    pluginState.logger.error('发送回复失败:', err);
    return false;
  }
}

/**
 * 发送合并转发消息。将多条消息合并为一条可展开查看的聊天记录，避免刷屏。
 */
async function sendForwardMsg(
  ctx: NapCatPluginContext,
  target: number | string,
  isGroup: boolean,
  nodes: ForwardNode[],
): Promise<boolean> {
  try {
    const actionName = isGroup ? 'send_group_forward_msg' : 'send_private_forward_msg';
    const params: any = { message: nodes };
    if (isGroup) params.group_id = String(target);
    else params.user_id = String(target);
    await ctx.actions.call(actionName as any, params, ctx.adapterName, ctx.pluginManager.config);
    return true;
  } catch (err) {
    pluginState.logger.error('发送合并转发失败:', err);
    return false;
  }
}

/**
 * 创建一个合并转发节点，用于展示单条插画信息。
 */
function buildForwardNode(
  illust: IllustInfo,
  botId?: string,
): ForwardNode {
  // 构造插画标题与标签信息
  const titleLine = `${illust.title} - ${illust.author}`;
  const tagLine = illust.tags.length > 0 ? `标签: ${illust.tags.join(', ')}` : '';
  const content = [
    textSegment(`${titleLine}\n${tagLine}\n`),
    imageSegment(illust.url),
  ];
  const node: ForwardNode = {
    type: 'node',
    data: {
      nickname: 'PixivBot',
      content,
    },
  };
  // 若提供了机器人 ID，则设置 user_id 为机器人 ID，从而让转发节点显示机器人头像
  if (botId) {
    node.data.user_id = botId;
  }
  return node;
}

/**
 * 主消息处理函数。当收到消息事件时由 plugin_onmessage 调用。
 * 判断是否匹配指令并执行搜索或推荐操作。
 */
export async function handleMessage(
  ctx: NapCatPluginContext,
  event: OB11Message,
): Promise<void> {
  try {
    // 仅处理消息事件
    if (event.post_type !== MESSAGE_POST_TYPE) return;
    if (!pluginState.config.enabled) return;
    const rawMessage: string = (event.raw_message || '').trim();
    if (!rawMessage) return;
    const prefix = pluginState.config.commandPrefix || '#pixiv';
    if (!rawMessage.startsWith(prefix)) return;
    // 提取命令参数
    const args = rawMessage.slice(prefix.length).trim().split(/\s+/).filter(Boolean);
    // 如果没有参数，发送帮助
    if (args.length === 0) {
      const helpLines = [
        'Pixiv 插件帮助',
        `${prefix} <关键词> - 搜索含有关键词的插画`,
        `${prefix} rec - 获取随机推荐插画`,
        `${prefix} 推荐 - 获取随机推荐插画`,
        `${prefix} help - 显示本帮助`,
      ];
      await sendReply(ctx, event, helpLines.join('\n'));
      return;
    }
    const sub = args[0].toLowerCase();
    // 处理帮助指令
    if (sub === 'help' || sub === '帮助') {
      const helpLines = [
        'Pixiv 插件帮助',
        `${prefix} <关键词> - 搜索含有关键词的插画`,
        `${prefix} rec - 获取随机推荐插画`,
        `${prefix} 推荐 - 获取随机推荐插画`,
        `${prefix} help - 显示本帮助`,
      ];
      await sendReply(ctx, event, helpLines.join('\n'));
      return;
    }
    const maxResults = pluginState.config.maxResults || 3;
    const allowR18 = pluginState.config.allowR18 || false;
    // 推荐指令
    if (sub === 'rec' || sub === '推荐') {
      const illusts = await recommendIllusts(maxResults, allowR18);
      if (illusts.length === 0) {
        await sendReply(ctx, event, '未找到推荐插画，请稍后再试。');
        return;
      }
      // 如果只有一张图片，直接发送
      if (illusts.length === 1) {
        const illust = illusts[0];
        const segments = [
          textSegment(`${illust.title} - ${illust.author}\n` + (illust.tags.length > 0 ? `标签: ${illust.tags.join(', ')}\n` : '')),
          imageSegment(illust.url),
        ];
        await sendReply(ctx, event, segments as any);
        return;
      }
      // 多张图片，构建合并转发。显式传入机器人的 QQ 号用于隐藏触发者信息。
      const botId = event.self_id ? String(event.self_id) : undefined;
      const nodes: ForwardNode[] = illusts.map((i) => buildForwardNode(i, botId));
      const isGroup = event.message_type === 'group';
      const target = isGroup ? event.group_id! : event.user_id!;
      await sendForwardMsg(ctx, target, isGroup, nodes);
      return;
    }
    // 默认认为剩余参数是搜索关键字
    const query = args.join(' ');
    const illusts = await searchIllusts(query, maxResults, allowR18);
    if (illusts.length === 0) {
      await sendReply(ctx, event, `未找到与 “${query}” 相关的插画。`);
      return;
    }
    // 如果只有一张图片，直接发送
    if (illusts.length === 1) {
      const illust = illusts[0];
      const segments = [
        textSegment(`${illust.title} - ${illust.author}\n` + (illust.tags.length > 0 ? `标签: ${illust.tags.join(', ')}\n` : '')),
        imageSegment(illust.url),
      ];
      await sendReply(ctx, event, segments as any);
      return;
    }
    // 多张图片，构建合并转发。显式传入机器人的 QQ 号用于隐藏触发者信息。
    const botId2 = event.self_id ? String(event.self_id) : undefined;
    const nodes: ForwardNode[] = illusts.map((i) => buildForwardNode(i, botId2));
    const isGroup = event.message_type === 'group';
    const target = isGroup ? event.group_id! : event.user_id!;
    await sendForwardMsg(ctx, target, isGroup, nodes);
  } catch (err) {
    pluginState.logger.error('处理消息时出错:', err);
  }
}