/**
 * NapCat Pixiv 插件主入口
 *
 * 提供搜索与推荐 Pixiv 插画的功能，支持合并转发多张图片，避免刷屏。
 */

// 为了在未安装 napcat-types 的环境下编译，通过 any 类型替代具体类型定义。
type PluginModule = any;
type PluginConfigSchema = any;
type NapCatPluginContext = any;
// OneBot 规范中的消息事件 post_type 为 'message'，无需从包中导入。
import { buildConfigSchema, defaultConfig, type PluginConfig } from './config';
import { pluginState } from './core/state';
import { handleMessage } from './handlers/message-handler';

// 导出用于生成 WebUI 配置面板的 Schema。将在 plugin_init 中赋值。
export let plugin_config_ui: PluginConfigSchema = [];

/**
 * 插件初始化。在 NapCat 加载插件时调用。用于初始化全局状态与配置。该函数必须存在。
 */
export const plugin_init = async (ctx: any) => {
  try {
    // 初始化全局状态
    pluginState.init(ctx);
    // 初始化配置。如果系统已经有保存的配置，则 pluginState.init 会合并。
    pluginState.replaceConfig({ ...defaultConfig(), ...pluginState.config });
    // 生成配置 Schema，用于 WebUI
    plugin_config_ui = buildConfigSchema(ctx);
    ctx.logger.info('Pixiv 插件初始化完成');
  } catch (err) {
    ctx.logger.error('Pixiv 插件初始化失败:', err);
  }
};

/**
 * 消息事件处理。仅处理 OneBot 消息事件。
 */
export const plugin_onmessage = async (
  ctx: any,
  event: any,
) => {
  // 仅处理消息事件
  if (!event || event.post_type !== 'message') return;
  await handleMessage(ctx, event);
};

/**
 * 当配置在 WebUI 中变更时触发。支持单项更新。
 */
export const plugin_on_config_change = async (
  ctx: any,
  ui: any,
  key: any,
  value: any,
  currentConfig: any,
) => {
  try {
    // 更新内存中的配置
    pluginState.updateConfig({ [key]: value } as Partial<PluginConfig>);
    ctx.logger.debug(`Pixiv 插件配置 ${String(key)} 已更新`);
  } catch (err) {
    ctx.logger.error('更新配置失败:', err);
  }
};

/**
 * 获取当前配置。供 NapCat 调用。
 */
export const plugin_get_config = async () => {
  return pluginState.config;
};

/**
 * 替换整个配置。当用户点击保存时调用。
 */
export const plugin_set_config = async (
  ctx: any,
  config: any,
) => {
  pluginState.replaceConfig(config as PluginConfig);
  ctx.logger.info('Pixiv 插件配置已替换');
};

/**
 * 插件卸载或重载时的清理函数。
 */
export const plugin_cleanup = async (ctx: any) => {
  ctx.logger.info('Pixiv 插件已卸载');
};